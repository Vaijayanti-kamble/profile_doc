package com.example.profile_doc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileDocApplicationTests {

	@Test
	void contextLoads() {
	}

}
